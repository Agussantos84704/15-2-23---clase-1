![Inove banner](inove.jpg)
Inove Escuela de Código\
info@inove.com.ar\
Web: [Inove](http://inove.com.ar)

__Ejemplos que el profesor mostrará en clase__\
ejemplos_clase/


# ¡Hola mundo! [Web]
En este repositorio encontraran un archivo index html el cual los ayudara a verificar que su entorno se encuentra bien instalado y configurado. Para verificar que todo esta en orden, seguiremos los proximos pasos:

1- Abrir el archivo index.html con nuestro editor de código (Visual Studio Code)\
2- Copiaremos el siguiente código: 
```
  <h1>Hola mundo web!</h1>
  <h2>Coloque su nombre aquí</h2>
 ```
4- Guardaremos los cambios y posteriormente abrimos el archivo index.html con doble click.\
5- Finalmente tomaremos una captura de pantalla del editor de código (Visual Studio Code) y de nuestra página web, para posteriormente subirla al campus.

Ayudas:\
-Para tomar captura de pantalla en Windows, podemos presionar el botón de Windows y buscar "Recortes", este es un programa que viene integrado el cual nos puede permitir tomar capturas de pantalla.

# Consultas
alumnos@inove.com.ar
